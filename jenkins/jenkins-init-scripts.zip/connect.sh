ssh -i ec2_instance/jenkins-Administrator.pem ec2-user@ec2-13-58-66-142.us-east-2.compute.amazonaws.com
